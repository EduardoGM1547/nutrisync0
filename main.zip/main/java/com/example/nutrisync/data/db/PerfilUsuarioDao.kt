package com.example.nutrisync.data.db

import androidx.room.*
import com.example.nutrisync.data.model.PerfilUsuario

@Dao
interface PerfilUsuarioDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(perfil: PerfilUsuario)

    @Query("SELECT * FROM PerfilUsuario WHERE id = :id LIMIT 1")
    suspend fun obtenerPorId(id: Int): PerfilUsuario?

    // Lista todos los clientes asignados a un entrenador
    @Query("SELECT * FROM PerfilUsuario WHERE entrenadorId = :entrenadorId")
    suspend fun obtenerPorEntrenador(entrenadorId: String): List<PerfilUsuario>
}
