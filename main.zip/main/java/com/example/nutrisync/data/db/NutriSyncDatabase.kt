package com.example.nutrisync.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.nutrisync.data.model.PerfilUsuario
import com.example.nutrisync.data.model.RegistroHabito

@Database(
    entities = [RegistroHabito::class, PerfilUsuario::class],
    version = 4,
    exportSchema = false
)
abstract class NutriSyncDatabase : RoomDatabase() {
    abstract fun registroHabitoDao(): RegistroHabitoDao
    abstract fun perfilUsuarioDao(): PerfilUsuarioDao

    companion object {

        // MIGRACIÓN DE V2 a V3: cambia id a INTEGER, agrega nuevos campos
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // 1. Crear nueva tabla con id INTEGER
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS RegistroHabito_new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        userId TEXT NOT NULL,
                        hizoEjercicio INTEGER NOT NULL,
                        detalleEjercicio TEXT NOT NULL DEFAULT '',
                        desayuno INTEGER NOT NULL,
                        detalleDesayuno TEXT NOT NULL DEFAULT '',
                        comida INTEGER NOT NULL,
                        detalleComida TEXT NOT NULL DEFAULT '',
                        cena INTEGER NOT NULL,
                        detalleCena TEXT NOT NULL DEFAULT '',
                        horasSueno INTEGER NOT NULL,
                        peso REAL NOT NULL,
                        entrenadorId TEXT,
                        fecha TEXT NOT NULL,
                        fechaModificacion TEXT,
                        sincronizado INTEGER NOT NULL
                    )
                """.trimIndent())

                // 2. Copiar datos SIN id (se regenerará)
                database.execSQL("""
                    INSERT INTO RegistroHabito_new (
                        userId, hizoEjercicio, detalleEjercicio, desayuno, detalleDesayuno,
                        comida, detalleComida, cena, detalleCena, horasSueno, peso, entrenadorId,
                        fecha, fechaModificacion, sincronizado
                    )
                    SELECT userId, hizoEjercicio, detalleEjercicio, desayuno, detalleDesayuno,
                           comida, detalleComida, cena, detalleCena, horasSueno, peso, entrenadorId,
                           fecha, fechaModificacion, sincronizado
                    FROM RegistroHabito
                """.trimIndent())

                // 3. Borrar tabla antigua
                database.execSQL("DROP TABLE RegistroHabito")
                // 4. Renombrar la nueva
                database.execSQL("ALTER TABLE RegistroHabito_new RENAME TO RegistroHabito")
            }
        }

        @Volatile
        private var INSTANCE: NutriSyncDatabase? = null

        fun getDatabase(context: Context): NutriSyncDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NutriSyncDatabase::class.java,
                    "nutrisync_db"
                )
                    .addMigrations(MIGRATION_2_3)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
