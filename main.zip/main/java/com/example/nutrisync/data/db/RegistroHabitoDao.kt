package com.example.nutrisync.data.db

import androidx.room.*
import com.example.nutrisync.data.model.RegistroHabito

@Dao
interface RegistroHabitoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(registro: RegistroHabito)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarTodos(registros: List<RegistroHabito>)

    @Query("SELECT * FROM RegistroHabito WHERE userId = :userId ORDER BY fecha DESC")
    suspend fun obtenerTodos(userId: String): List<RegistroHabito>

    @Query("SELECT * FROM RegistroHabito WHERE sincronizado = 0 AND userId = :userId")
    suspend fun obtenerNoSincronizados(userId: String): List<RegistroHabito>

    @Update
    suspend fun actualizar(registro: RegistroHabito)

    @Query("DELETE FROM RegistroHabito WHERE id = :id")
    suspend fun eliminar(id: Int)

    @Query("DELETE FROM RegistroHabito")
    suspend fun borrarTodos()

    @Query("SELECT * FROM RegistroHabito WHERE userId = :userId")
    suspend fun obtenerTodosPorUsuario(userId: Int): List<RegistroHabito>

}