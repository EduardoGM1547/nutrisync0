package com.example.nutrisync.data

import android.content.Context
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.RegistroHabito
import com.example.nutrisync.network.ApiClient


class RegistroRepository(private val context: Context) {
    private val registroDao = NutriSyncDatabase.getDatabase(context).registroHabitoDao()

    suspend fun guardarRegistro(registro: RegistroHabito, userId: String) {
        registroDao.insertar(registro)
    }

    suspend fun obtenerTodos(userId: String): List<RegistroHabito> {
        return registroDao.obtenerTodos(userId)
    }
    suspend fun getUnsyncedRecords(userId: String): List<RegistroHabito> {
        return registroDao.obtenerNoSincronizados(userId)
    }
    suspend fun syncRecordsToCloud(registros: List<RegistroHabito>) {
        for (registro in registros) {
            val response = ApiClient.create(context).crearRegistro(registro)
            if (response.isSuccessful) {
                registroDao.insertar(registro.copy(sincronizado = true))
            }
        }
    }
    suspend fun syncFromCloud(userId: String) {
        val response = ApiClient.create(context).obtenerRegistros(userId)
        if (response.isSuccessful) {
            val registrosDesdeNube = response.body() ?: emptyList()
            registroDao.insertarTodos(registrosDesdeNube.map {
                it.copy(sincronizado = true)
            })
        }
    }
}