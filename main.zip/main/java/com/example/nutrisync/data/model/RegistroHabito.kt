package com.example.nutrisync.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class RegistroHabito(
    @PrimaryKey(autoGenerate = true) val id: Int? = null,
    val userId: String,
    val hizoEjercicio: Boolean,
    val detalleEjercicio: String = "",
    val desayuno: Boolean,
    val detalleDesayuno: String = "",
    val comida: Boolean,
    val detalleComida: String = "",
    val cena: Boolean,
    val detalleCena: String = "",
    val horasSueno: Int,
    val peso: Float,
    val entrenadorId: String? = null,
    val fecha: String,
    val fechaModificacion: String? = null,
    val sincronizado: Boolean = false
)