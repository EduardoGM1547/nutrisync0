package com.example.nutrisync.ui.cliente


import android.widget.Toast
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.PerfilUsuario
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun PerfilUsuarioScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()
    var isDark by remember { mutableStateOf(false) }

    // Rol: true = coach, false = cliente
    val isCoach = AuthManager.getUserRole(context) == "entrenador"

    var nombre by remember { mutableStateOf("") }
    var edad by remember { mutableStateOf("") }
    var altura by remember { mutableStateOf("") }
    var objetivo by remember { mutableStateOf("") }

    // Cargar datos existentes y adaptar altura a la unidad de visualización
    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
        val existente = db.perfilUsuarioDao().obtenerPorId(1)
        existente?.let {
            nombre = it.nombre
            edad = it.edad.toString()
            altura = if (isCoach) {
                // Coach: mostrar en metros con 2 decimales
                String.format("%.2f", it.altura / 100.0f)
            } else {
                // Cliente: mostrar en centímetros
                it.altura.toInt().toString()
            }
            objetivo = it.objetivo
        }
    }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Perfil de Usuario"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = edad,
                onValueChange = { nuevo ->
                    // Solo acepta números
                    if (nuevo.isEmpty() || nuevo.all { it.isDigit() }) edad = nuevo
                },
                label = { Text("Edad") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            OutlinedTextField(
                value = altura,
                onValueChange = { nuevo ->
                    // Solo acepta números y un punto decimal
                    if (nuevo.isEmpty() || nuevo.matches(Regex("^\\d*\\.?\\d*\$"))) altura = nuevo
                },
                label = { Text(if (isCoach) "Altura (m)" else "Altura (cm)") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = altura.isNotEmpty() && !altura.matches(Regex("^\\d*\\.?\\d*\$"))
            )

            OutlinedTextField(
                value = objetivo,
                onValueChange = { objetivo = it },
                label = { Text("Objetivo personal") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(onClick = {
                val edadInt = edad.toIntOrNull()
                val alturaCm = if (isCoach) {
                    // Coach: convierte metros a cm
                    altura.replace(",", ".").toFloatOrNull()?.times(100)?.toInt()
                } else {
                    altura.toIntOrNull()
                }

                if (nombre.isNotBlank() && edadInt != null && alturaCm != null) {
                    val perfil = PerfilUsuario(
                        id = 1,
                        nombre = nombre,
                        entrenadorId = null,
                        edad = edadInt,
                        altura = alturaCm.toFloat(), // SIEMPRE guarda en cm
                        objetivo = objetivo
                    )

                    scope.launch(Dispatchers.IO) {
                        db.perfilUsuarioDao().insertar(perfil)
                        launch(Dispatchers.Main) {
                            Toast.makeText(context, "Perfil guardado correctamente", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(context, "Completa todos los campos correctamente", Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Guardar")
            }

            Button(onClick = { navController.popBackStack() }) {
                Text("Volver")
            }
        }
    }
}