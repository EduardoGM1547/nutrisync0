package com.example.nutrisync.ui.cliente

import android.graphics.Color
import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.RegistroHabito
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import com.example.nutrisync.ui.utils.isLandscape
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun PesoGraficaScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    var registros by remember { mutableStateOf<List<RegistroHabito>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val landscape = isLandscape()

    // Estado para tema oscuro
    var isDark by remember { mutableStateOf(false) }

    // Al iniciar, lee el modo oscuro de las preferencias
    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
        scope.launch(Dispatchers.IO) {
            val userId = AuthManager.getUserId(context)
            if (userId != null) {
                registros = db.registroHabitoDao().obtenerTodos(userId).sortedBy { it.fecha }
            }
        }
    }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Gráfica de Peso"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (registros.isNotEmpty()) {
                AndroidView(
                    factory = { ctx ->
                        LineChart(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                if (landscape) 800 else 600
                            )
                        }
                    },
                    update = { chart ->
                        val entries = registros.mapIndexed { index, r ->
                            Entry(index.toFloat(), r.peso)
                        }

                        // Color adaptativo a modo claro/oscuro
                        val textColor = if (isDark) Color.WHITE else Color.BLACK

                        val dataSet = LineDataSet(entries, "Peso (kg)").apply {
                            color = Color.BLUE
                            valueTextColor = textColor
                            setCircleColor(Color.MAGENTA)
                            lineWidth = 2f
                            circleRadius = 4f
                        }

                        val fechas = registros.map { it.fecha.take(10) }

                        chart.xAxis.valueFormatter = IndexAxisValueFormatter(fechas)
                        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
                        chart.xAxis.textColor = textColor // Eje X
                        chart.axisLeft.textColor = textColor // Eje Y
                        chart.axisRight.isEnabled = false
                        chart.legend.textColor = textColor // Leyenda
                        chart.description.text = "Historial de peso"
                        chart.description.textColor = textColor // Descripción
                        chart.data = LineData(dataSet)
                        chart.invalidate()
                    }
                )
            } else {
                Text(
                    "Aún no hay datos de peso.",
                    color = if (isDark) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Volver")
            }
        }
    }
}
