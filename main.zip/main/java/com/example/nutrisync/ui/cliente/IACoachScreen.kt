package com.example.nutrisync.ui.cliente

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.nutrisync.viewmodels.NutritionExpertViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IACoachScreen(navController: NavController, viewModel: NutritionExpertViewModel = viewModel()) {
    var pregunta by remember { mutableStateOf(TextFieldValue("")) }
    val mensajes by viewModel.messages.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(mensajes.size) {
        if (mensajes.isNotEmpty()) {
            listState.animateScrollToItem(mensajes.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("IA Coach Nutricional") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(mensajes) { msg ->
                    Surface(color = MaterialTheme.colorScheme.secondaryContainer) {
                        Text(msg.text, modifier = Modifier.padding(8.dp))
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = pregunta,
                    onValueChange = { pregunta = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Pregunta a la IA") },
                    enabled = !isLoading
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (pregunta.text.isNotBlank()) {
                            viewModel.sendUserMessage(pregunta.text)
                            pregunta = TextFieldValue("")
                        }
                    },
                    enabled = !isLoading
                ) {
                    Text("Consultar")
                }
            }
        }
    }
}
