package com.example.nutrisync.ui.cliente

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.RegistroRepository
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.data.model.RegistroHabito
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun RegistroHabitosScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { RegistroRepository(context) }
    val userId = AuthManager.getUserId(context) ?: ""
    val isEntrenador = AuthManager.getUserRole(context) == "entrenador"
    var isDark by remember { mutableStateOf(false) }

    var hizoEjercicio by rememberSaveable { mutableStateOf(false) }
    var desayuno by rememberSaveable { mutableStateOf(false) }
    var comida by rememberSaveable { mutableStateOf(false) }
    var cena by rememberSaveable { mutableStateOf(false) }
    var horasSueno by rememberSaveable { mutableStateOf("") }
    var peso by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
    }

    var detalleEjercicio by rememberSaveable { mutableStateOf("") }
    var detalleDesayuno by rememberSaveable { mutableStateOf("") }
    var detalleComida by rememberSaveable { mutableStateOf("") }
    var detalleCena by rememberSaveable { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = if (isEntrenador) "Registro para Cliente" else "Mis Hábitos"
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Ejercicio
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = hizoEjercicio, onCheckedChange = { hizoEjercicio = it })
                    Text("¿Hiciste ejercicio hoy?")
                }
                if (hizoEjercicio) {
                    OutlinedTextField(
                        value = detalleEjercicio,
                        onValueChange = { detalleEjercicio = it },
                        label = { Text("¿Qué ejercicio(s) hiciste?") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Comidas
            item { Text("Comidas consumidas:") }

            // Desayuno
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = desayuno, onCheckedChange = { desayuno = it })
                    Text("Desayuno")
                }
                if (desayuno) {
                    OutlinedTextField(
                        value = detalleDesayuno,
                        onValueChange = { detalleDesayuno = it },
                        label = { Text("¿Qué desayunaste?") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Comida
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = comida, onCheckedChange = { comida = it })
                    Text("Comida")
                }
                if (comida) {
                    OutlinedTextField(
                        value = detalleComida,
                        onValueChange = { detalleComida = it },
                        label = { Text("¿Qué comiste?") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Cena
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = cena, onCheckedChange = { cena = it })
                    Text("Cena")
                }
                if (cena) {
                    OutlinedTextField(
                        value = detalleCena,
                        onValueChange = { detalleCena = it },
                        label = { Text("¿Qué cenaste?") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Horas de sueño
            item {
                OutlinedTextField(
                    value = horasSueno,
                    onValueChange = { nuevo ->
                        // Solo acepta números
                        if (nuevo.isEmpty() || nuevo.all { it.isDigit() }) horasSueno = nuevo
                    },
                    label = { Text("Horas de sueño") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )
            }

            // Peso
            item {
                OutlinedTextField(
                    value = peso,
                    onValueChange = { nuevoPeso ->
                        // Solo acepta números y un punto decimal
                        if (nuevoPeso.isEmpty() || nuevoPeso.matches(Regex("^\\d*\\.?\\d*\$"))) {
                            peso = nuevoPeso
                        }
                    },
                    label = { Text("Peso actual (kg)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = peso.isNotEmpty() && !peso.matches(Regex("^\\d*\\.?\\d*\$"))
                )
            }

            // Guardar
            item {
                Button(onClick = {
                    scope.launch {
                        val horas = horasSueno.toIntOrNull()
                        val pesoFloat = peso.toFloatOrNull()

                        if (horas != null && pesoFloat != null) {
                            val fechaActual = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                            val fechaMod = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

                            repository.guardarRegistro(
                                RegistroHabito(
                                    userId = userId,
                                    hizoEjercicio = hizoEjercicio,
                                    detalleEjercicio = detalleEjercicio,
                                    desayuno = desayuno,
                                    detalleDesayuno = detalleDesayuno,
                                    comida = comida,
                                    detalleComida = detalleComida,
                                    cena = cena,
                                    detalleCena = detalleCena,
                                    horasSueno = horas,
                                    peso = pesoFloat,
                                    entrenadorId = if (isEntrenador) userId else null,
                                    fecha = fechaActual,
                                    fechaModificacion = fechaMod
                                ),
                                userId
                            )
                            Toast.makeText(context, "Hábitos guardados", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(
                                context,
                                "Ingresa valores válidos para horas de sueño y peso",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }) {
                    Text("Guardar hábitos")
                }
            }

            item {
                Divider(thickness = 1.dp, color = MaterialTheme.colorScheme.primary)
            }

            item {
                Button(onClick = { navController.popBackStack() }) {
                    Text("Volver")
                }
            }
        }
    }
}