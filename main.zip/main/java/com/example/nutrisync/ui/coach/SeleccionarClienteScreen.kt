package com.example.nutrisync.ui.coach

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.PerfilUsuario
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun SeleccionarClienteScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    var clientes by remember { mutableStateOf<List<PerfilUsuario>>(emptyList()) }
    val scope = rememberCoroutineScope()
    var isDark by remember { mutableStateOf(false) }
    val coachId = AuthManager.getUserId(context)
    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
        scope.launch(Dispatchers.IO) {
            clientes = db.perfilUsuarioDao().obtenerPorEntrenador(coachId ?: "")
        }
    }
    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Selecciona un cliente"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (clientes.isEmpty()) {
                Text("Aún no tienes clientes asignados.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(clientes) { cliente ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.navigate("habitosEntrenador/${cliente.id}")
                                }
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Nombre: ${cliente.nombre}")
                                Text("ID: ${cliente.id}")
                            }
                        }
                    }
                }
            }
        }
    }
}