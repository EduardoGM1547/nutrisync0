package com.example.nutrisync.ui.coach

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.PerfilUsuario
import com.example.nutrisync.network.AuthManager
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun AgregarClienteScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    val scope = rememberCoroutineScope()
    val coachId = AuthManager.getUserId(context) ?: "trainer123"
    var isDark by remember { mutableStateOf(false) }
    var nombre by remember { mutableStateOf("") }
    var edad by remember { mutableStateOf("") }
    var altura by remember { mutableStateOf("") }
    var objetivo by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
    }
    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Agregar Cliente"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = edad,
                onValueChange = { edad = it },
                label = { Text("Edad") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = altura,
                onValueChange = { altura = it },
                label = { Text("Altura (m)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = objetivo,
                onValueChange = { objetivo = it },
                label = { Text("Objetivo") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = {
                val edadInt = edad.toIntOrNull()
                val alturaFloat = altura.toFloatOrNull()
                if (nombre.isNotBlank() && edadInt != null && alturaFloat != null) {
                    val idCliente = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                    val perfil = PerfilUsuario(
                        id = idCliente,
                        nombre = nombre,
                        entrenadorId = coachId,
                        edad = edadInt,
                        altura = alturaFloat,
                        objetivo = objetivo
                    )
                    scope.launch(Dispatchers.IO) {
                        db.perfilUsuarioDao().insertar(perfil)
                        launch(Dispatchers.Main) {
                            Toast.makeText(context, "Cliente agregado", Toast.LENGTH_SHORT).show()
                            navController.popBackStack()
                        }
                    }
                } else {
                    Toast.makeText(context, "Completa todos los campos correctamente", Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Agregar Cliente")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.popBackStack() }) {
                Text("Volver")
            }
        }
    }
}