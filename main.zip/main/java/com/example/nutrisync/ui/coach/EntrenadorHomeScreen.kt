package com.example.nutrisync.ui.coach

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.ThemePreference
import com.example.nutrisync.ui.components.TopBarWithThemeToggle
import kotlinx.coroutines.launch

@Composable
fun EntrenadorHomeScreen(navController: NavController, onThemeChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isDark by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isDark = ThemePreference.isDarkMode(context)
    }
    Scaffold(
        topBar = {
            TopBarWithThemeToggle(
                isDarkTheme = isDark,
                onToggleTheme = {
                    isDark = !isDark
                    scope.launch {
                        ThemePreference.setDarkMode(context, isDark)
                        onThemeChanged(isDark)
                    }
                },
                title = "Panel de Entrenador"
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp), // Igual que cliente
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = { navController.navigate("seleccionarCliente") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp), // Separación, no altura fija
                shape = RoundedCornerShape(50)
            ) {
                Text("Hábitos")
            }
            Button(
                onClick = { navController.navigate("enviarPlanes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(50)
            ) {
                Text("Enviar planes")
            }
            Button(
                onClick = { navController.navigate("perfilEntrenador") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(50)
            ) {
                Text("Perfil")
            }
            Button(
                onClick = { navController.navigate("agregarCliente") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(50)
            ) {
                Text("Agregar Cliente")
            }
        }
    }
}