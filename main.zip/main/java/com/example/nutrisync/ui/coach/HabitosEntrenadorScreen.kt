package com.example.nutrisync.ui.coach

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.nutrisync.data.db.NutriSyncDatabase
import com.example.nutrisync.data.model.RegistroHabito
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HabitosEntrenadorScreen(
    navController: NavController,
    userId: Int // Pasado por argumento de navegación
) {
    val context = LocalContext.current
    val db = remember { NutriSyncDatabase.getDatabase(context) }
    var registros by remember { mutableStateOf<List<RegistroHabito>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(userId) {
        scope.launch(Dispatchers.IO) {
            registros = db.registroHabitoDao().obtenerTodosPorUsuario(userId).sortedBy { it.fecha }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Hábitos de Cliente") })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (registros.isEmpty()) {
                Text("No hay registros aún para este usuario.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(registros) { registro ->
                        Card {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Fecha: ${registro.fecha}")
                                Text("Peso: ${registro.peso} kg")
                                Text("Ejercicio: ${if (registro.hizoEjercicio) "Sí" else "No"}")
                                Text("Comidas: Desayuno: ${if (registro.desayuno) "Sí" else "No"}, Comida: ${if (registro.comida) "Sí" else "No"}, Cena: ${if (registro.cena) "Sí" else "No"}")
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { navController.popBackStack() }) {
                Text("Volver")
            }
        }
    }
}
