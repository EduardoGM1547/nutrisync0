package com.example.nutrisync.sync.helpers

import com.example.nutrisync.data.model.RegistroHabito
import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement

object RegistroHabitoSyncHelper {
    private const val URL = "jdbc:mysql://bx1iauu4mymemmse9coj-mysql.services.clever-cloud.com:3306/bx1iauu4mymemmse9coj"
    private const val USER = "uyu2jn2dhf3yalof"
    private const val PASSWORD = "T2mzOq4sfV5VJkeAkETK"

    private fun conectar(): Connection? {
        return try {
            Class.forName("com.mysql.cj.jdbc.Driver") // usa com.mysql.cj.jdbc.Driver si tienes MySQL 8
            DriverManager.getConnection(URL, USER, PASSWORD)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun insertarRegistro(registro: RegistroHabito): Boolean {
        val conn = conectar() ?: return false
        val sql = """
            INSERT INTO registro_habito (
                id, user_id, entrenador_id, fecha,
                hizo_ejercicio, desayuno, comida, cena,
                horas_sueno, peso, sincronizado, fecha_modificacion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                hizo_ejercicio = VALUES(hizo_ejercicio),
                desayuno = VALUES(desayuno),
                comida = VALUES(comida),
                cena = VALUES(cena),
                horas_sueno = VALUES(horas_sueno),
                peso = VALUES(peso),
                sincronizado = VALUES(sincronizado),
                fecha_modificacion = VALUES(fecha_modificacion)
        """.trimIndent()

        return try {
            val stmt: PreparedStatement = conn.prepareStatement(sql)
            stmt.setInt(1, registro.id ?: 0)
            stmt.setString(2, registro.userId)
            stmt.setString(3, registro.entrenadorId)
            stmt.setString(4, registro.fecha)
            stmt.setBoolean(5, registro.hizoEjercicio)
            stmt.setBoolean(6, registro.desayuno)
            stmt.setBoolean(7, registro.comida)
            stmt.setBoolean(8, registro.cena)
            stmt.setInt(9, registro.horasSueno)
            stmt.setFloat(10, registro.peso)
            stmt.setBoolean(11, true)
            stmt.setString(12, registro.fechaModificacion)

            stmt.executeUpdate()
            stmt.close()
            conn.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}