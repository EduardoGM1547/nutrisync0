package com.example.nutrisync.sync.helpers

import android.content.Context
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.nutrisync.sync.SyncService
import com.example.nutrisync.sync.SyncWorker

object SyncUtils {
    fun triggerImmediateSync(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val syncRequest = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueue(syncRequest)
    }

    fun schedulePeriodicSync(context: Context) {
        SyncService.start(context)
    }

    fun cancelAllSyncs(context: Context) {
        WorkManager.getInstance(context).cancelAllWork()
    }
}