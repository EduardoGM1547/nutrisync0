package com.example.nutrisync.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class NutritionExpertViewModel : ViewModel() {

    sealed class MessageUiState {
        abstract val text: String
        abstract val timestamp: String

        data class UserMessage(
            override val text: String,
            override val timestamp: String = currentTimeFormatted()
        ) : MessageUiState()

        data class AssistantMessage(
            override val text: String,
            override val timestamp: String = currentTimeFormatted()
        ) : MessageUiState()

        data class SystemMessage(
            override val text: String,
            override val timestamp: String = ""
        ) : MessageUiState()
    }

    private val _messages = MutableStateFlow<List<MessageUiState>>(emptyList())
    val messages: StateFlow<List<MessageUiState>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val foodDatabase = mapOf(
        "manzana" to "🍎 Buena fuente de fibra (4g) y vitamina C. Aproximadamente 95 kcal por unidad.",
        "pollo" to "🍗 Proteína magra (31g por 100g). Ideal para recuperación muscular. 165 kcal por 100g.",
        "aguacate" to "🥑 Grasas saludables (15g por 100g). Rico en vitamina E y potasio. 160 kcal por 100g.",
        "espinaca" to "🥬 Rica en hierro (2.7mg por 100g), antioxidantes y vitaminas A y C. Solo 23 kcal por 100g.",
        "plátano" to "🍌 Fuente rápida de energía, potasio y vitamina B6. Aproximadamente 105 kcal por unidad.",
        "arroz" to "🍚 Carbohidratos complejos, energía sostenida. Aproximadamente 130 kcal por 100g cocido.",
        "huevo" to "🥚 Proteína completa y nutrientes esenciales. 78 kcal por unidad mediana.",
        "salmón" to "🐟 Rico en ácidos grasos omega-3 y proteínas. 208 kcal por 100g.",
        "lentejas" to "🥣 Fuente vegetal de proteínas (9g/100g) y fibra. 116 kcal por 100g cocidas."
    )

    private val exerciseTips = listOf(
        "🏃‍♂️ Camina 30 minutos al día para mejorar tu salud cardiovascular y quemar alrededor de 150 kcal.",
        "💪 Realiza 3 series de 10 flexiones para fortalecer torso y brazos.",
        "🧘‍♀️ Practica yoga o estiramientos para mejorar flexibilidad y reducir estrés.",
        "🚴‍♂️ Andar en bicicleta 20 minutos ayuda a fortalecer piernas y mejorar resistencia.",
        "🏋️‍♂️ Haz entrenamiento de fuerza 3 veces por semana para aumentar masa muscular."
    )

    private val hydrationTips = listOf(
        "💧 Bebe al menos 2 litros de agua al día para mantenerte hidratado.",
        "🥤 Evita bebidas azucaradas para cuidar tu salud y peso corporal."
    )

    private val sleepTips = listOf(
        "😴 Duerme entre 7 y 9 horas por noche para una buena recuperación y salud general.",
        "📵 Evita usar dispositivos electrónicos al menos 30 minutos antes de dormir para mejorar la calidad del sueño.",
        "🛏️ Mantén un horario regular para acostarte y levantarte, incluso fines de semana.",
        "🌙 Crea un ambiente oscuro, fresco y tranquilo en tu habitación para favorecer el descanso."
    )

    private val generalTips = listOf(
        "🥦 Incluye una variedad de frutas y verduras en tu dieta diaria.",
        "🍽️ Come porciones moderadas y evita comer en exceso.",
        "🛌 Duerme al menos 7-8 horas para favorecer tu recuperación y bienestar.",
        "🚶‍♂️ Mantente activo durante el día para mejorar tu metabolismo."
    )

    private val mentalHealthTips = listOf(
        "🧠 Consume alimentos ricos en omega-3 como salmón y nueces para mejorar la memoria.",
        "📚 Realiza ejercicios de concentración y descanso mental para mayor claridad.",
        "💤 El sueño adecuado es esencial para la salud cognitiva y el aprendizaje.",
        "🧘‍♀️ Dedica 10 minutos al día a la meditación para reducir el estrés.",
        "📵 Haz pausas digitales. Alejarte del celular mejora el bienestar mental.",
        "👥 Habla con amigos o familiares cuando te sientas abrumado.",
        "📖 Lee o realiza una actividad creativa para desconectar de la rutina.",
        "🚶‍♂️ Sal a caminar al aire libre. El contacto con la naturaleza mejora el estado de ánimo.",
        "🧠 Consume alimentos ricos en omega-3 como salmón y nueces para la salud cerebral.",
        "💤 Duerme bien. La falta de sueño afecta directamente la estabilidad emocional.",
        "✍️ Escribe un diario. Expresar tus pensamientos puede aliviar la ansiedad."
    )
    private val gymRoutines = mapOf(
        "principiante" to """
            🏋️‍♀️ Rutina para Principiantes (3 días):
            • Día 1: Sentadillas (3x12), Press de pecho con mancuernas (3x10), Planchas (3x30s)
            • Día 2: Caminata rápida o bicicleta (30 min)
            • Día 3: Peso muerto con mancuerna (3x10), Remo con banda (3x12), Abdominales (3x15)
        """.trimIndent(),

        "intermedio" to """
            🏋️‍♂️ Rutina Intermedia (4 días):
            • Día 1: Sentadillas con barra, Press de banca, Remo con barra
            • Día 2: Cardio HIIT (20 min) + Core (4 ejercicios)
            • Día 3: Peso muerto, Dominadas asistidas, Press militar
            • Día 4: Cardio moderado (30 min) + Estiramientos
        """.trimIndent(),

        "avanzado" to """
            🏆 Rutina Avanzada (5-6 días):
            • Lunes: Piernas (peso muerto, sentadillas, desplantes)
            • Martes: Pecho y tríceps (press banca, fondos)
            • Miércoles: Espalda y bíceps (dominadas, remo)
            • Jueves: Cardio + core
            • Viernes: Hombros + circuito funcional
            • Sábado (opcional): Full body o descanso activo
        """.trimIndent()
    )

    init {
        initializeChat()
    }

    private fun initializeChat() {
        addAssistantMessage("¡Hola! 👋 Soy NutriBot, tu coach de nutrición, ejercicio, sueño y bienestar. Pregúntame sobre alimentos, planes, ejercicios, hidratación, sueño o salud mental.")
    }

    fun sendUserMessage(message: String) {
        if (message.isBlank()) return

        addUserMessage(message)

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = inferResponse(message)
                addAssistantMessage(response)
            } catch (e: Exception) {
                addAssistantMessage("⚠️ Ocurrió un error: ${e.localizedMessage ?: "Intenta nuevamente."}")
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun inferResponse(message: String): String {
        val text = message.lowercase(Locale.getDefault()).trim()

        val mentionedFood = foodDatabase.keys.find { key -> Regex("\\b$key\\b").containsMatchIn(text) }
        val wantsPlan = text.contains("plan")
        val wantsExercise = text.contains("ejercicio") || text.contains("entrenamiento")
        val wantsGym = text.contains("gimnasio") || text.contains("gym") || text.contains("rutina de fuerza")
        val wantsHydration = text.contains("hidratación") || text.contains("agua") || text.contains("beber")
        val wantsSleep = text.contains("sueño") || text.contains("dormir") || text.contains("descanso")
        val wantsGeneral = text.contains("consejo") || text.contains("tip") || text.contains("recomendación")
        val wantsMentalHealth = text.contains("salud mental") || text.contains("memoria") || text.contains("concentración") || text.contains("cerebro") || text.contains("ánimo") || text.contains("estrés") || text.contains("ansiedad")

        val wantsBeginner = text.contains("principiante")
        val wantsIntermediate = text.contains("intermedio")
        val wantsAdvanced = text.contains("avanzado")

        // Nuevos términos para control de peso y tipos de dieta
        val wantsLoseWeight = text.contains("bajar de peso") || text.contains("adelgazar") || text.contains("perder peso")
        val wantsGainWeight = text.contains("subir de peso") || text.contains("aumentar peso")
        val wantsMaintainWeight = text.contains("mantener peso") || text.contains("peso ideal")

        val wantsVegetarian = text.contains("vegetariana") || text.contains("vegano")
        val wantsKeto = text.contains("keto") || text.contains("cetogénica") || text.contains("cetogenica")
        val wantsLowCarb = text.contains("baja en carbohidratos") || text.contains("low carb")

        val feelsTired = text.contains("fatiga") || text.contains("cansado") || text.contains("agotado") || text.contains("falta de energía")

        val responseParts = mutableListOf<String>()

        // Inferencia extendida según condiciones
        if (wantsPlan) responseParts.add(generateNutritionPlan())

        if (wantsLoseWeight) responseParts.add(
            "⚖️ Para bajar de peso, reduce calorías, aumenta actividad física y prioriza proteínas magras y vegetales."
        )
        if (wantsGainWeight) responseParts.add(
            "⚖️ Para aumentar peso de forma saludable, consume alimentos densos en nutrientes y haz entrenamiento de fuerza."
        )
        if (wantsMaintainWeight) responseParts.add(
            "⚖️ Para mantener un peso saludable, equilibra tus calorías y mantente activo regularmente."
        )

        if (wantsVegetarian) responseParts.add(
            "🥗 Una dieta vegetariana balanceada debe incluir proteínas vegetales como legumbres, tofu y frutos secos."
        )
        if (wantsKeto) responseParts.add(
            "🥓 La dieta cetogénica es baja en carbohidratos y alta en grasas saludables. Consulta a un especialista antes de iniciar."
        )
        if (wantsLowCarb) responseParts.add(
            "🍳 Las dietas bajas en carbohidratos pueden ayudar a controlar el peso, pero asegúrate de consumir suficiente fibra."
        )

        if (feelsTired) responseParts.add(
            "😴 Si te sientes fatigado, revisa tu descanso, alimentación y nivel de hidratación. El ejercicio moderado también ayuda."
        )

        if (wantsExercise) responseParts.add("💡 Consejo de ejercicio: ${exerciseTips.random()}")
        if (wantsHydration) responseParts.add("💡 Consejo de hidratación: ${hydrationTips.random()}")
        if (wantsSleep) responseParts.add("💡 Consejo de sueño: ${sleepTips.random()}")
        if (wantsGeneral) responseParts.add("💡 Consejo general: ${generalTips.random()}")
        if (wantsMentalHealth) responseParts.add("🧠 Consejo salud mental: ${mentalHealthTips.random()}")

        if (wantsGym || wantsBeginner || wantsIntermediate || wantsAdvanced) {
            when {
                wantsBeginner -> responseParts.add(gymRoutines["principiante"]!!)
                wantsIntermediate -> responseParts.add(gymRoutines["intermedio"]!!)
                wantsAdvanced -> responseParts.add(gymRoutines["avanzado"]!!)
                else -> responseParts.add("¿Qué nivel de rutina de gimnasio prefieres? (principiante, intermedio, avanzado)")
            }
        }

        if (mentionedFood != null) {
            responseParts.add("Información sobre ${mentionedFood}:\n${foodDatabase[mentionedFood]}")
        }

        if (responseParts.isEmpty()) {
            return """
                No entendí tu consulta. Puedes intentar con:
                - Preguntar sobre alimentos, ejemplo: "manzana"
                - Pedir un "plan" nutricional
                - Consultar consejos de "ejercicio"
                - Consultar sobre "hidratación"
                - Consultar sobre "sueño"
                - Consultar sobre "salud mental"
                - Consultar sobre control de peso (bajar, subir, mantener)
                - Preguntar por dietas específicas (vegetariana, keto, baja en carbohidratos)
            """.trimIndent()
        }

        return responseParts.joinToString(separator = "\n\n")
    }

    private fun generateNutritionPlan(): String {
        return """
            📝 Plan Nutricional Básico
            
            🍽️ Desayuno:
            • Avena con frutas y nueces (300 kcal)
            
            🥗 Almuerzo:
            • Ensalada con pollo, aguacate y arroz integral (450 kcal)
            
            🐟 Cena:
            • Pescado al vapor con vegetales (400 kcal)
            
            🍎 Snack:
            • Yogur natural o fruta fresca
            
            💡 Consejos:
            • Bebe 2L de agua al día
            • Incluye proteína en cada comida
            • Prefiere alimentos integrales y frescos
            • Realiza ejercicio regularmente
            • Duerme entre 7 y 9 horas cada noche
        """.trimIndent()
    }

    private fun addUserMessage(text: String) {
        _messages.value = _messages.value + MessageUiState.UserMessage(text)
    }

    private fun addAssistantMessage(text: String) {
        _messages.value = _messages.value + MessageUiState.AssistantMessage(text)
    }

    private fun addSystemMessage(text: String) {
        _messages.value = _messages.value + MessageUiState.SystemMessage(text)
    }

    companion object {
        private fun currentTimeFormatted(): String {
            return SimpleDateFormat("HH:mm", Locale.getDefault())
                .format(System.currentTimeMillis())
        }
    }
}
